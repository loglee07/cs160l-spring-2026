package edu.sdsu.cs160l;

/**
 * Lab9: Complete all todos in
 * 1) {@link edu.sdsu.cs160l.datastructure.array.ArrayExample}
 * 2) {@link edu.sdsu.cs160l.datastructure.linkedlist.LinkedListExample}
 * 3) {@link edu.sdsu.cs160l.datastructure.linkedlist.SinglyLinkedList}
 * 4) {@link edu.sdsu.cs160l.datastructure.queue.QueueExample}
 */

/**
 * Lab10: Complete all todos in
 * 1) {@link edu.sdsu.cs160l.algorithm.search.BinarySearch}
 * 2) {@link edu.sdsu.cs160l.algorithm.sort.MergeSort}
 * 3) {@link edu.sdsu.cs160l.datastructure.Parenthesis}
 */
public class DataMain {
    public static void main(String[] args) {
        System.out.print("Hello");
    }
}
